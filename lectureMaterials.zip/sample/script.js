// script.js

const allQuestions = [
    {
        question: "Q. 결함 식별 및 품질 평가를 위한 활동은?",
        options: ["디버그", "결함", "검증(Verification)", "테스트"],
        answer: "테스트"
    },
    {
        question: "Q. 입력과 예상 결과를 정의한 테스트 단위는?",
        options: ["테스트 케이스", "결함", "검증(Verification)", "테스트"],
        answer: "테스트 케이스"
    },
    {
        question: "Q. 요구사항에 맞게 올바르게 만들어졌는지 확인하는 것은?",
        options: ["테스트 케이스", "결함", "검증(Verification)", "테스트"],
        answer: "검증(Verification)"
    },
    {
        question: "Q. 테스트/불만으로 발견된 결함 원인 추적.수정하는 개발 활동은?",
        options: ["테스트 케이스", "디버깅", "검증(Verification)", "테스트"],
        answer: "디버깅"
    },
    {
        question: "Q. SW 실행 없이 코드, 문서, 설계 등을 검토하는 테스팅 기법, 주로 오류를 예방하거나 초기에 발견하기 위해 사용하는 테스팅 방법은?",
        options: ["블랙박스 테스트", "디버깅", "정적테스팅", "경험기반 테스트"],
        answer: "정적테스팅"
    },
    {
        question: "Q. 테스트가 된 정도를 나타내는 용어는?",
        options: ["블랙박스 테스트", "커버리지", "기능 테스트", "경험기반 테스트"],
        answer: "커버리지"
    }
];

let gameQuestions = [];
let currentQuestionIndex = 0;
let playerHP = 50;
let dragonHP = 50;
let gems = 0;
let selectedCharacter = null;
let isAnimating = false;

// DOM Elements
const screens = {
    title: document.getElementById('title-screen'),
    game: document.getElementById('game-screen'),
    gameOver: document.getElementById('game-over-screen'),
    clear: document.getElementById('clear-screen')
};

const charBtns = document.querySelectorAll('.char-btn');
const startBtn = document.getElementById('start-btn');
const homeBtn = document.getElementById('home-btn');
const retryBtn = document.getElementById('retry-btn');
const replayBtn = document.getElementById('replay-btn');

const playerHPBar = document.getElementById('player-hp-bar');
const playerHPText = document.getElementById('player-hp-text');
const dragonHPBar = document.getElementById('dragon-hp-bar');
const dragonHPText = document.getElementById('dragon-hp-text');
const gemCount = document.getElementById('gem-count');

const playerImg = document.getElementById('player-img');
const sadPlayerImg = document.getElementById('sad-player-img');
const gameDragonImg = document.getElementById('game-dragon-img');
const dragonMessage = document.getElementById('dragon-message');
const fireEffect = document.getElementById('fire-effect');
const effectOverlay = document.getElementById('effect-overlay');
const effectText = document.getElementById('effect-text');

const questionText = document.getElementById('question-text');
const answersContainer = document.getElementById('answers-container');

// Event Listeners
charBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        charBtns.forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        selectedCharacter = btn.dataset.char;
        startBtn.classList.remove('disabled');
    });
});

startBtn.addEventListener('click', () => {
    if (selectedCharacter && !startBtn.classList.contains('disabled')) {
        startGame();
    }
});

[homeBtn, retryBtn, replayBtn].forEach(btn => {
    btn.addEventListener('click', showTitleScreen);
});

// Functions
function showScreen(screenName) {
    Object.values(screens).forEach(screen => screen.classList.remove('active'));
    screens[screenName].classList.add('active');
}

function showTitleScreen() {
    showScreen('title');
    selectedCharacter = null;
    charBtns.forEach(b => b.classList.remove('selected'));
    startBtn.classList.add('disabled');
}

function shuffleArray(array) {
    let shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

function startGame() {
    playerHP = 50;
    dragonHP = 50;
    gems = 0;
    currentQuestionIndex = 0;
    isAnimating = false;
    
    // Set character images
    const charSrc = selectedCharacter === 'wizard' ? 'assets/wizard.png' : 'assets/warrior.png';
    playerImg.src = charSrc;
    playerImg.className = 'player-idle'; // Reset class list
    sadPlayerImg.src = charSrc;
    document.getElementById('clear-player-img').src = charSrc;
    document.getElementById('player-name').innerText = selectedCharacter === 'wizard' ? '마법사' : '전사';

    updateStatusUI();
    dragonMessage.innerText = "드래곤이 내는 퀴즈를 맞추면 보석을 얻을 수 있습니다!";
    
    // Prepare questions (shuffle questions and options)
    gameQuestions = shuffleArray(allQuestions).map(q => {
        return {
            ...q,
            options: shuffleArray(q.options)
        };
    });

    loadQuestion();
    showScreen('game');
}

function updateStatusUI() {
    playerHPText.innerText = `${playerHP}/50`;
    playerHPBar.style.width = `${(playerHP / 50) * 100}%`;
    
    dragonHPText.innerText = `${dragonHP}/50`;
    dragonHPBar.style.width = `${(dragonHP / 50) * 100}%`;
    
    gemCount.innerText = gems;
}

function loadQuestion() {
    if (currentQuestionIndex >= gameQuestions.length) return;
    
    const currentQ = gameQuestions[currentQuestionIndex];
    questionText.innerText = currentQ.question;
    
    answersContainer.innerHTML = '';
    currentQ.options.forEach(option => {
        const btn = document.createElement('button');
        btn.classList.add('answer-btn');
        btn.innerText = option;
        btn.addEventListener('click', () => selectAnswer(btn, option, currentQ.answer));
        answersContainer.appendChild(btn);
    });
}

function selectAnswer(btn, selected, correct) {
    if (isAnimating) return;
    isAnimating = true;
    
    // Disable all buttons
    const buttons = answersContainer.querySelectorAll('.answer-btn');
    buttons.forEach(b => b.disabled = true);
    
    if (selected === correct) {
        // Correct answer
        btn.classList.add('correct');
        handleCorrectAnswer();
    } else {
        // Wrong answer
        btn.classList.add('wrong');
        handleWrongAnswer();
    }
}

function handleCorrectAnswer() {
    let damage = 10;
    if (selectedCharacter === 'wizard') damage = 15;
    else if (selectedCharacter === 'warrior') damage = 8;
    
    let dragonEvaded = false;
    if (selectedCharacter === 'warrior') {
        dragonEvaded = Math.random() < 0.5; // 50% chance
        if (dragonEvaded) {
            damage = 0;
            dragonMessage.innerText = "내 공격을 막다니 아깝네.";
        } else {
            dragonMessage.innerText = "크아아! 정답이다!";
        }
    } else {
        dragonMessage.innerText = "크아아! 정답이다!";
    }

    // Update stats
    dragonHP = Math.max(0, dragonHP - damage);
    gems += 1;
    updateStatusUI();
    
    // Animations
    playerImg.classList.remove('player-idle');
    playerImg.classList.add('attack-animation');
    
    setTimeout(() => {
        if (damage > 0) {
            fireEffect.classList.remove('hidden');
            dragonHPBar.parentElement.classList.add('shake-animation');
        }
        
        if (dragonEvaded) {
            effectText.innerText = "막힘!";
            effectText.style.color = "var(--neon-gold)";
            effectText.style.textShadow = "0 0 20px var(--neon-gold)";
        } else {
            effectText.innerText = "정답!";
            effectText.style.color = "var(--neon-green)";
            effectText.style.textShadow = "0 0 20px var(--neon-green)";
        }
        effectOverlay.classList.remove('hidden');
        
        setTimeout(() => {
            playerImg.classList.remove('attack-animation');
            playerImg.classList.add('player-idle');
            fireEffect.classList.add('hidden');
            dragonHPBar.parentElement.classList.remove('shake-animation');
            effectOverlay.classList.add('hidden');
            
            checkGameState();
        }, 1500);
    }, 500);
}

function handleWrongAnswer() {
    let damage = 10;
    if (selectedCharacter === 'wizard') damage = 15;
    
    let playerEvaded = false;
    if (selectedCharacter === 'warrior') {
        playerEvaded = Math.random() < 0.5; // 50% chance
        if (playerEvaded) {
            damage = 0;
            dragonMessage.innerText = "운 좋게 피했네!";
        } else {
            dragonMessage.innerText = "다시 풀어보세요.";
        }
    } else {
        dragonMessage.innerText = "다시 풀어보세요.";
    }

    // Update stats
    playerHP = Math.max(0, playerHP - damage);
    updateStatusUI();
    
    // Animations
    gameDragonImg.classList.remove('dragon-idle');
    gameDragonImg.classList.add('shake-animation');
    
    if (!playerEvaded) {
        playerHPBar.parentElement.classList.add('shake-animation');
    }
    
    if (playerEvaded) {
        effectText.innerText = "회피!";
        effectText.style.color = "var(--neon-blue)";
        effectText.style.textShadow = "0 0 20px var(--neon-blue)";
    } else {
        effectText.innerText = "오답!";
        effectText.style.color = "var(--neon-red)";
        effectText.style.textShadow = "0 0 20px var(--neon-red)";
    }
    effectOverlay.classList.remove('hidden');
    
    setTimeout(() => {
        gameDragonImg.classList.remove('shake-animation');
        gameDragonImg.classList.add('dragon-idle');
        playerHPBar.parentElement.classList.remove('shake-animation');
        effectOverlay.classList.add('hidden');
        
        if (playerHP <= 0) {
            isAnimating = true;
            dragonMessage.innerText = "드래곤에게 패배했습니다... 😢";
            playerImg.classList.remove('player-idle');
            playerImg.classList.add('grayscale');
            
            setTimeout(() => {
                showScreen('gameOver');
            }, 2000);
        } else {
            isAnimating = false;
            // Re-enable buttons for retry
            const buttons = answersContainer.querySelectorAll('.answer-btn');
            buttons.forEach(b => {
                b.disabled = false;
                b.classList.remove('wrong');
            });
        }
    }, 1500);
}

function checkGameState() {
    if (dragonHP <= 0) {
        isAnimating = true;
        dragonMessage.innerText = "드래곤을 길들였습니다! 🐉✨";
        playerImg.classList.remove('player-idle');
        playerImg.classList.add('victory-animation');
        
        setTimeout(() => {
            document.querySelector('.gem-reward .neon-text-gold').innerText = gems;
            showScreen('clear');
        }, 2000);
    } else {
        currentQuestionIndex++;
        loadQuestion();
        isAnimating = false;
    }
}
