## 경기공유학교 2026
# 가족과 함께하는 AI를 통한 바이브코딩(유한대학교)

2026.07.25

## 방탈출 게임 만들기

- 오늘 만들어볼 것은?
- 수수께끼를 풀어 방을 탈출하는 게임 만들기

## 방탈출 게임 만들기

//버튼 누르면 링크의 주소로 이동하도록 구현해줘.

'더 드리프터'에 놀란 게이머들. 함께 즐기는 전설의 어드벤처 명작 6선
https://youtu.be/8kbDxDhs6Hs?si=qv20XqnocOEpy-by

90년대 인기 어드벤처 게임
https://youtu.be/sQW5c0a05PE?si=ehdw7G0MUpZiTlgZ

2026년 상반기 최고의 기대작 TOP 10
https://youtu.be/sRJvJBRxvJE?si=dCqvIXSpyLcw9JWa

## 방탈출 특화 설계 규칙

- 한 곳에 오래 머물러 있어야 하기 때문에 방의 분위기가 왜곡되어 있는 경향이 있음
- 방에 움직이는 오브젝트들이 있어서 힌트를 얻을 수 있도록 해줌
- 수수께끼나 퍼즐과 같은 문제풀이 요소들을 만들어어 푸는 재미가 있음

//버튼을 클릭하면 방탈출 설계서가 나옴

방탈출 게임 기획서 작성기
https://luriluan0-a11y.github.io/Source/escapeRoom/escapeRoom_paper.html

1. 먼저 배경 사진을 고름
2. 기획서 작성기에 예시대로 기획서를 작성함
3. 완성되면 마크다운 파일 다운로드함
4. Antigravity IDE를 열고 "마크다운 파일을 읽고 html 단일 페이지로 개발해줘." 라고 요청함
5. 완성되면 html 파일을 열어서 확인해봄


